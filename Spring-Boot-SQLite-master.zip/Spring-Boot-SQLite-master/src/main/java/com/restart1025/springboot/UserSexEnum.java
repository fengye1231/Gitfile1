package com.restart1025.springboot;

public enum UserSexEnum {
	MAN, WOMAN
}
