package com.yuxue.service;


public interface FaceService {
    
    public Object recognise(String filePath, boolean reRecognise);

}