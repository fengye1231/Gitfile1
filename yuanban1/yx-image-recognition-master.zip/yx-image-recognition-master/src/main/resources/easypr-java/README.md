# easypr-java

#### 介绍
easypr java版项目的实现过程代码
该文件夹下代码， 基于org.bytedeco.javacpp包实现的，**后续统一使用org.opencv官方包实现，故将这部分代码放这里供参考**
JavaCPP是一个开源库，它提供了在 Java 中高效访问本地 C++的方法；

#### 如果要使用这种方案
详细请参考开发环境搭建文档： javacpp方式调用

