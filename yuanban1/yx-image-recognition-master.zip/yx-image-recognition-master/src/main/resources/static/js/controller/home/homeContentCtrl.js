/**
 * @desc 登录页面模块
 * @author [刘耀填]
 * @date 2018/09/11
 */
require(['../../js/common/common.config.js'], function() {
    require(["constant", "homeContentMod"], function(constant, homeContentMod) {
        homeContentMod.init();
    });
});